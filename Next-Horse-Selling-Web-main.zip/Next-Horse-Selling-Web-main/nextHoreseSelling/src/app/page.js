// import styles from "./page.module.css";
import Hero from "@/Components/Hero/Hero";
import Custom from "@/Components/Custom/Custom";
import Services from "@/Components/Services/Services";
import Posts from "@/Components/Posts/Post";
import SecondHeader from "@/Components/SecondHeader/SecondHeader";
import News from "@/Components/News/News";
import Footer from "@/Components/Footer/Footer";
export default function Home() {
  return (
    <main>
      <Hero />
      <Custom />
      <Services />
      <Posts />
      <SecondHeader />
      <News />
      <Footer />
    </main>
  );
}
