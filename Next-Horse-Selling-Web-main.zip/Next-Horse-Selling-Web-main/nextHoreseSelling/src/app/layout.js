import "./globals.css";
import Navbar from "@/Components/Navbar/navbar";
// import Footer from "@/Components/Footer/Footer";
export const metadata = {
  title: "Horse Selling - Easy Coding Tutorial",
  description: "Go And Subscribe",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      {/* Bootstrap CDN */}
      <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        precedence="default"
      />
      <body>
        <Navbar />
        {children}
        {/* <Footer /> */}
      </body>
    </html>
  );
}
