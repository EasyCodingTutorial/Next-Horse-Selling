import styles from "./News.module.css";
const News = () => {
  return (
    <>
      <div className={styles.News}>
        <div className="container">
          <div className="row">
            <div className="col-sm-4">
              <div className={styles.Newsbox}>
                <img src="/post1.jpg" className="img-fluid" alt="" />
                <div className={styles.boxContent}>
                  <h6>Post Title: The Magnificent World of Horse Breeds</h6>
                  <p>
                    Description: Take a captivating journey through the diverse
                    and fascinating world of horse breeds. From elegant Arabians
                    to powerful Friesians, explore the unique traits, histories,
                    and characteristics that make each breed special. Discover
                    which breed might be the perfect match for your equestrian
                    dreams!
                  </p>
                </div>
              </div>
            </div>
            <div className="col-sm-4">
              <div className={styles.Newsbox}>
                <img src="/post2.jpg" className="img-fluid" alt="" />
                <div className={styles.boxContent}>
                  <h6>Post Title: The Magnificent World of Horse Breeds</h6>
                  <p>
                    Description: Take a captivating journey through the diverse
                    and fascinating world of horse breeds. From elegant Arabians
                    to powerful Friesians, explore the unique traits, histories,
                    and characteristics that make each breed special. Discover
                    which breed might be the perfect match for your equestrian
                    dreams!
                  </p>
                </div>
              </div>
            </div>{" "}
            <div className="col-sm-4">
              <div className={styles.Newsbox}>
                <img src="/post3.jpg" className="img-fluid" alt="" />
                <div className={styles.boxContent}>
                  <h6>Post Title: The Magnificent World of Horse Breeds</h6>
                  <p>
                    Description: Take a captivating journey through the diverse
                    and fascinating world of horse breeds. From elegant Arabians
                    to powerful Friesians, explore the unique traits, histories,
                    and characteristics that make each breed special. Discover
                    which breed might be the perfect match for your equestrian
                    dreams!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default News;
