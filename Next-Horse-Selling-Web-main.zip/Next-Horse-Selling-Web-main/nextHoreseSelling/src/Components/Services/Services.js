import styles from "./Service.module.css";
const Services = () => {
  return (
    <>
      <div className={styles.Services}>
        <div className="container">
          <div className={styles.content}>
            <h6>
              Our <span>Services</span>
            </h6>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
          </div>

          <div className="row">
            <div className="col-sm-4">
              <div className={styles.ServicesBox}>
                <img src="/service1.jpg" className="img-fluid" alt="" />
                <div className={styles.BoxContent}>
                  <h6>Horse Listings And Sales</h6>
                  <p>
                    Provide a comprehensive catalog of horses available for
                    sale, each with detailed information, including breed, age,
                    gender, temperament, training level, and images. Facilitate
                    the process for potential buyers to inquire about and
                    purchase horses.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-sm-4">
              <div className={styles.ServicesBox}>
                <img src="/service2.jpg" className="img-fluid" alt="" />
                <div className={styles.BoxContent}>
                  <h6>Horse Listings And Sales</h6>
                  <p>
                    Provide a comprehensive catalog of horses available for
                    sale, each with detailed information, including breed, age,
                    gender, temperament, training level, and images. Facilitate
                    the process for potential buyers to inquire about and
                    purchase horses.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-sm-4">
              <div className={styles.ServicesBox}>
                <img src="/service3.jpg" className="img-fluid" alt="" />
                <div className={styles.BoxContent}>
                  <h6>Horse Listings And Sales</h6>
                  <p>
                    Provide a comprehensive catalog of horses available for
                    sale, each with detailed information, including breed, age,
                    gender, temperament, training level, and images. Facilitate
                    the process for potential buyers to inquire about and
                    purchase horses.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-sm-4">
              <div className={styles.ServicesBox}>
                <img src="/service4.jpg" className="img-fluid" alt="" />
                <div className={styles.BoxContent}>
                  <h6>Horse Listings And Sales</h6>
                  <p>
                    Provide a comprehensive catalog of horses available for
                    sale, each with detailed information, including breed, age,
                    gender, temperament, training level, and images. Facilitate
                    the process for potential buyers to inquire about and
                    purchase horses.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-sm-4">
              <div className={styles.ServicesBox}>
                <img src="/service5.jpg" className="img-fluid" alt="" />
                <div className={styles.BoxContent}>
                  <h6>Horse Listings And Sales</h6>
                  <p>
                    Provide a comprehensive catalog of horses available for
                    sale, each with detailed information, including breed, age,
                    gender, temperament, training level, and images. Facilitate
                    the process for potential buyers to inquire about and
                    purchase horses.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-sm-4">
              <div className={styles.ServicesBox}>
                <img src="/service6.jpg" className="img-fluid" alt="" />
                <div className={styles.BoxContent}>
                  <h6>Horse Listings And Sales</h6>
                  <p>
                    Provide a comprehensive catalog of horses available for
                    sale, each with detailed information, including breed, age,
                    gender, temperament, training level, and images. Facilitate
                    the process for potential buyers to inquire about and
                    purchase horses.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Services;
