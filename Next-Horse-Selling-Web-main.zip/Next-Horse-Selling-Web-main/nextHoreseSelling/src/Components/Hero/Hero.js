import styles from "./Hero.module.css";
const Hero = () => {
  return (
    <>
      <div className={styles.Home}>
        <div className={styles.HomeContent}>
          <h6>Best Solutions For Your Loneliness</h6>
          <h5>
            Discover Your Perfect <span>Companion</span> <br /> at Our{" "}
            <span>Horse</span> Haven!
          </h5>
          <p>
            Welcome to our enchanting Horse Haven, where dreams come alive and
            lifelong bonds are forged! Our carefully curated selection of
            majestic horses awaits to find their perfect riders. <br />
            Whether you're a seasoned equestrian seeking a new partner or a
            passionate newcomer eager to embark on an unforgettable journey, we
            have the ideal companion for you. Explore our captivating horse
            listings, filled with detailed information and stunning imagery, and
            witness the magic that unfolds when humans and horses unite.
            Unbridle your dreams and gallop into greatness with us today!
          </p>
        </div>
      </div>
    </>
  );
};
export default Hero;
