import styles from "./SecondHeader.module.css";
const SecondHeader = () => {
  return (
    <>
      <div className={styles.secondHeader}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-sm-8">
              <h6>
                Saddle up for love's gentle ride, where horse and heart unite
                side by side.
              </h6>
              <p>
                Welcome to a world where the rhythm of hoofbeats intertwines
                with the melody of beating hearts, creating a harmonious
                symphony of love and connection. Our enchanting realm is where
                dreams unfold and bonds are woven between humans and horses.{" "}
                <br />
                <br />
                Imagine the soft nuzzle of a horse's velvety nose, a gesture of
                affection that transcends words. Here, the genuine and heartfelt
                exchange between riders and their equine companions forms the
                foundation of an extraordinary relationship.
                <br />
                <br />
                In the saddle, riders embark on a journey of trust and
                understanding, where they become one with their majestic steeds.
                Each ride becomes a dance of grace and beauty, as rider and
                horse move in perfect synchrony, guided by an unspoken language
                of love and unity.
                <br />
                <br />
                In our world, love knows no bounds, and the connection shared
                with these noble creatures transcends the ordinary. The joyous
                laughter of riders mingles with the soft whinny of horses,
                filling the air with warmth and happiness.
                <br />
                <br />
                We invite you to step into this realm of wonder, where the
                gentle cadence of hooves soothes the soul and where hearts find
                solace in the presence of these magnificent creatures. Together,
                let us embrace the magic of this extraordinary bond and embark
                on a journey of love's gentle ride, where horse and heart unite
                side by side.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default SecondHeader;
