import styles from "./Footer.module.css";
const Footer = () => {
  return (
    <>
      <footer className={styles.Footer}>
        <a href="#">&copy; Easy Coding Tutorial</a>
      </footer>
    </>
  );
};
export default Footer;
