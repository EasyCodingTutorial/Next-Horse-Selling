import styles from "./Post.module.css";
const Posts = () => {
  return (
    <>
      <div className={styles.PopularPosts}>
        <div className="container">
          <div className={styles.content}>
            <h6>
              Popuplar <span>Posts</span>
            </h6>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
          </div>
          <div className="row">
            <div className="col-sm-3">
              <div className={styles.PopupBox}>
                <img src="/product1.jpg" className="img-fluid" alt="" />
                <div className={styles.PopuplarBoxContent}>
                  <h6>Equestrian Riding Gear</h6>
                  <p>
                    Offer a variety of high-quality riding gear such as saddles,
                    bridles, stirrups, reins, and riding helmets. Provide
                    options for different riding disciplines, sizes, and styles
                    to cater to the needs of both beginners and experienced
                    riders.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-sm-3">
              <div className={styles.PopupBox}>
                <img src="/product2.jpg" className="img-fluid" alt="" />
                <div className={styles.PopuplarBoxContent}>
                  <h6>Equestrian Riding Gear</h6>
                  <p>
                    Offer a variety of high-quality riding gear such as saddles,
                    bridles, stirrups, reins, and riding helmets. Provide
                    options for different riding disciplines, sizes, and styles
                    to cater to the needs of both beginners and experienced
                    riders.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-sm-3">
              <div className={styles.PopupBox}>
                <img src="/product3.jpg" className="img-fluid" alt="" />
                <div className={styles.PopuplarBoxContent}>
                  <h6>Equestrian Riding Gear</h6>
                  <p>
                    Offer a variety of high-quality riding gear such as saddles,
                    bridles, stirrups, reins, and riding helmets. Provide
                    options for different riding disciplines, sizes, and styles
                    to cater to the needs of both beginners and experienced
                    riders.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-sm-3">
              <div className={styles.PopupBox}>
                <img src="/product4.jpg" className="img-fluid" alt="" />
                <div className={styles.PopuplarBoxContent}>
                  <h6>Equestrian Riding Gear</h6>
                  <p>
                    Offer a variety of high-quality riding gear such as saddles,
                    bridles, stirrups, reins, and riding helmets. Provide
                    options for different riding disciplines, sizes, and styles
                    to cater to the needs of both beginners and experienced
                    riders.
                  </p>
                </div>
              </div>
            </div>

            {/* For Second */}
          </div>
        </div>
      </div>
    </>
  );
};
export default Posts;
