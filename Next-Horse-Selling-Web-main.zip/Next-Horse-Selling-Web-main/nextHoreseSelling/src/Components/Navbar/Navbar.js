import "./Navbar.css";
const Navbar = () => {
  return (
    <>
      <div className="navbarMain">
        <a href="#" className="navbar-brand">
          Easy
        </a>
        <div>
          <h6>Embrace the Opportunity: Let Us Handle Every Detail for You.</h6>
        </div>
      </div>

      {/*  */}
      <nav className="navbar navbar-expand">
        <ul className="navbar-nav">
          <li className="nav-item">
            <a href="#" className="nav-link">
              Home
            </a>
          </li>
          <li className="nav-item">
            <a href="#" className="nav-link">
              About
            </a>
          </li>
          <li className="nav-item">
            <a href="#" className="nav-link">
              Contact
            </a>
          </li>
          <li className="nav-item">
            <a href="#" className="nav-link">
              Shop
            </a>
          </li>
          <li className="nav-item">
            <a href="#" className="nav-link">
              Blogs
            </a>
          </li>
        </ul>
      </nav>
      {/*  */}
    </>
  );
};
export default Navbar;
