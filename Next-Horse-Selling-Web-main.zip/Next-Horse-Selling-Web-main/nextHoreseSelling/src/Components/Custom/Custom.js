import styles from "./Custom.module.css";
const Custom = () => {
  return (
    <>
      <div className={styles.Custom}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-sm-5">
              <img src="/custom.jpg" className="img-fluid" alt="" />
            </div>

            <div className="col-sm-5">
              <h6>You Buy a Horse For Emotional Connection.</h6>
              <p>
                When you decide to buy a horse, it goes far beyond a mere
                transaction; it's a heartfelt choice driven by the desire for a
                profound emotional connection. Owning a horse becomes an
                extraordinary journey of companionship, trust, and understanding
                that transcends words. <br />
                <br />
                In the graceful presence of your equine partner, a unique bond
                begins to flourish. Spending time together, grooming, and caring
                for each other's well-being, you find solace in the quiet
                moments and exhilaration in the spirited ones. <br />
                <br />
                As you ride through open fields or embark on new trails, a sense
                of unity envelops you both. Through the rhythmic sway of hooves
                and the gentle nudges of your companion, unspoken communication
                deepens your connection, creating a language all your own.{" "}
                <br />
                <br />
                In moments of joy, your laughter resonates with the echo of
                thundering hooves, and in times of challenge, your steadfast
                support is met with the unwavering loyalty of your equine
                confidant.
                <br />
              </p>
            </div>
          </div>

          {/* Second Row */}
          <div className="row justify-content-center">
            <div className="col-sm-5">
              <h6>You Buy a Horse For Emotional Connection.</h6>
              <p>
                When you decide to buy a horse, it goes far beyond a mere
                transaction; it's a heartfelt choice driven by the desire for a
                profound emotional connection. Owning a horse becomes an
                extraordinary journey of companionship, trust, and understanding
                that transcends words. <br />
                <br />
                In the graceful presence of your equine partner, a unique bond
                begins to flourish. Spending time together, grooming, and caring
                for each other's well-being, you find solace in the quiet
                moments and exhilaration in the spirited ones. <br />
                <br />
                As you ride through open fields or embark on new trails, a sense
                of unity envelops you both. Through the rhythmic sway of hooves
                and the gentle nudges of your companion, unspoken communication
                deepens your connection, creating a language all your own.{" "}
                <br />
                <br />
                In moments of joy, your laughter resonates with the echo of
                thundering hooves, and in times of challenge, your steadfast
                support is met with the unwavering loyalty of your equine
                confidant.
                <br />
              </p>
            </div>

            <div className="col-sm-5">
              <img src="/custom1.jpg" className="img-fluid" alt="" />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default Custom;
